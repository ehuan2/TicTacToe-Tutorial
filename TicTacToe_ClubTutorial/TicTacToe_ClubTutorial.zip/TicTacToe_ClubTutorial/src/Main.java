import javax.swing.*;

public class Main {

    public static void main(String[]args){

        GUI a = new GUI(Integer.parseInt(JOptionPane.showInputDialog(null, "Enter the size of the dimensions")));

    }

}
